package main

import (
	//"log"
	"fmt"
	"net/http"
	"text/template"
)

var plantillas = template.Must(template.ParseGlob("plantillas/*"))

func main() {

	http.HandleFunc("/", Inicio)
	http.HandleFunc("/add", Add)

	fmt.Println("Servidor Corriendo.....")
	http.ListenAndServe(":8080", nil)
}
func Inicio(w http.ResponseWriter, r *http.Request) {
	//fmt.Fprintf(w, "Hola Mateo")
	plantillas.ExecuteTemplate(w, "inicio", nil)

}
func Add(w http.ResponseWriter, r *http.Request) {
	plantillas.ExecuteTemplate(w, "add", nil)

}
